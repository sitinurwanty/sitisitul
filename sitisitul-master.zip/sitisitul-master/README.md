# sitisitul
Hallo Design
Desain biasa diterjemahkan sebagai seni terapan, arsitektur, dan berbagai pencapaian kreatif lainnya. Dalam sebuah kalimat, kata "desain" bisa digunakan, baik sebagai kata benda maupun kata kerja. Sebagai kata kerja, "desain" memiliki arti "proses untuk membuat dan menciptakan obyek baru". Sebagai kata benda, "desain" digunakan untuk menyebut hasil akhir dari sebuah proses kreatif, baik itu berwujud sebuah rencana, proposal, atau berbentuk benda nyata.

Proses desain pada umumnya memperhitungkan aspek fungsi, estetika, dan berbagai macam aspek lainnya dengan sumber data yang didapatkan dari riset, pemikiran, brainstorming, maupun dari desain yang sudah ada sebelumnya. Akhir-akhir ini, proses (secara umum) juga dianggap sebagai produk dari desain, sehingga muncul istilah "perancangan proses". Salah satu contoh dari perancangan proses adalah perancangan proses dalam industri kimia.
